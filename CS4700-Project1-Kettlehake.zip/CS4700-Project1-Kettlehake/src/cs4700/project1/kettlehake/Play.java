/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs4700.project1.kettlehake;

/**
 *
 * @author Joshua
 */
public class Play {
    private String ANO;
    private String MNO;
    private int Payment;

    public Play() {
    }

    public Play(String AMO, String NMO, int Payment) {
        this.ANO = AMO;
        this.MNO = NMO;
        this.Payment = Payment;
    }

    public String getANO() {
        return ANO;
    }

    public void setANO(String ANO) {
        this.ANO = ANO;
    }

    public String getMNO() {
        return MNO;
    }

    public void setMNO(String MNO) {
        this.MNO = MNO;
    }

    public int getPayment() {
        return Payment;
    }

    public void setPayment(int Payment) {
        this.Payment = Payment;
    }
    
    
}
