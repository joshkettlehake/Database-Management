/**
 * Joshua Kettlehake
 * Project 1
 * CS 4700
 */
package cs4700.project1.kettlehake;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class CS4700Project1Kettlehake {

    // Global variables
    private static Object[][] Result;
    private static int resultI;
    private static int resultJ;
    private static String f1;
    private static String f2;
    private static String f3;
    private static String f4;
    private static String f5;
    private static Object[][] FileOne;
    private static Object[][] FileTwo;
    private static Object[][] FileThree;
    private static Object[][] FileFour;
    private static Object[][] FileFive;
    private static String queriesFile;

    public static void main(String[] args) {
        Result = new Object[500][500];
        resultI = 0;
        resultJ = 0;
        // The readFile method takes in a string of the text file name.
        // For example, if your text file name is "abc.txt" you would enter "abc" into f1.
        // This would become FileOne (a 2D object array containing the data from the txt file.
        // Also, the name of the object array needs to be the same as the string inside of it.
        // It returns a 2 dimensional array of attributes.
        // CONSTRAINT: The files must be less than 100 objects x 100 lines.
        f1 = "Actors";
        f2 = "Movies";
        f3 = "Play";
        f4 = "";
        f5 = "";
        queriesFile = "RAqueries";
        if (f1 != "") {
            FileOne = readFile(f1);
        }
        if (f2 != "") {
            FileTwo = readFile(f2);
        }
        if (f3 != "") {
            FileThree = readFile(f3);
        }
        if (f4 != "") {
            FileFour = readFile(f4);
        }
        if (f5 != "") {
            FileFive = readFile(f5);
        }
        executeQueries(queriesFile);
    }

    // The files of f1-f5 and queriesFile are converted into 2D arrays.
    private static Object[][] readFile(String string) {
        Object[][] tempObjectArray = null;
        try {
            File file = new File(string + ".txt");
            Scanner fileReader = new Scanner(file).useDelimiter(", |\\r");
            tempObjectArray = new Object[100][100];
            int i = 0;
            int j = 0;
            String tempAttribute;
            boolean firstAttributeOnLine = false;
            String newline = "\n";
            boolean hasNewline;
            while (fileReader.hasNextLine()) {
                tempAttribute = fileReader.next();
                hasNewline = tempAttribute.contains(newline);
                if (hasNewline) {
                    firstAttributeOnLine = true;
                    i++;
                    j = 0;
                }
                if (firstAttributeOnLine) {
                    tempAttribute = tempAttribute.substring(1);
                    firstAttributeOnLine = false;
                }
                if (isNumeric(tempAttribute)) {
                    try {
                        int tempInt = Integer.parseInt(tempAttribute);
                        tempObjectArray[i][j] = tempInt;
                    } catch (NumberFormatException e) {
                        double tempDouble = Double.parseDouble(tempAttribute);
                        tempObjectArray[i][j] = tempDouble;
                    }
                } else {
                    tempObjectArray[i][j] = tempAttribute;
                }
                j++;
            }
            fileReader.close();

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return tempObjectArray;
    }

    // Helper method to changed Strings to ints and doubles as needed
    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Converts queriesFile into individual queries usable to this program.
    public static void executeQueries(String string) {
        try {
            Object[][] tempResultArray = new Object[100][100];
            File file = new File(string + ".txt");
            Scanner fileReader = new Scanner(file);
            String tempQuery = null;
            while (fileReader.hasNextLine()) {
                tempQuery = fileReader.nextLine();
                Result[resultI][resultJ] = tempQuery;
                resultI++;
                // Removing specific characters from the queries.
                tempQuery = tempQuery.replaceAll("[()]", " ");
                tempQuery = tempQuery.replaceAll("[{}]", " ");
                tempQuery = tempQuery.replaceAll("[,]", "");
                String[] stringTokenizedQuery = tempQuery.split("\\s+");
                Object[] objectTokenizedQuery = new Object[100];
                for (int l = 0; l < stringTokenizedQuery.length; l++) {
                    if (isNumeric(stringTokenizedQuery[l])) {
                        try {
                            int tempInt = Integer.parseInt(stringTokenizedQuery[l]);
                            objectTokenizedQuery[l] = tempInt;
                        } catch (NumberFormatException e) {
                            double tempDouble = Double.parseDouble(stringTokenizedQuery[l]);
                            objectTokenizedQuery[l] = tempDouble;
                        }
                    } else {
                        objectTokenizedQuery[l] = stringTokenizedQuery[l];
                    }
                }
                // Sending the queries to be solved
                tempResultArray = Quarterback(objectTokenizedQuery);
                // Adding the results to the Result 2D array.
                for (int i = 0; i < tempResultArray.length; i++) {
                    if (tempResultArray[i][0] == null) {
                        break;
                    }
                    for (int j = 0; j < tempResultArray[i].length; j++) {
                        if (tempResultArray[i][j] == null) {
                            break;
                        }
                        Result[resultI][resultJ] = tempResultArray[i][j];
                        resultJ++;
                    }
                    resultI++;
                    resultJ = 0;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        // Printing the results to RAoutput.csv
        printResults();
    }

    // This method distributes the queries to the necessary operation methods.
    // The name Quarterback is a reference to American Football.
    // He is the most important player, and he distributes the ball to the rest of the players...
    private static Object[][] Quarterback(Object[] objectTokenizedQuery) {
        Object[][] tempResultArray = new Object[100][100];
        // This solves a white space problem I was having.
        if (objectTokenizedQuery[0].equals("")) {
            for (int i = 0; i < objectTokenizedQuery.length; i++) {
                if (objectTokenizedQuery[i + 1] == null) {
                    objectTokenizedQuery[i] = null;
                    break;
                }
                objectTokenizedQuery[i] = objectTokenizedQuery[i + 1];
            }
        }
        Boolean hasTwoArgumentOperation = false;
        String twoArgumentType = "";
        int twoArgumentIndex = 0;
        String[] twoArgumentOperations = {"*", "X", "U", "INTE", "-"};
        String[] oneArgumentOperations = {"PROJ_", "SELE_"};

        // Checks to see if there is a two argument operation in the current query.
        for (int i = 0; i < objectTokenizedQuery.length; i++) {
            if (objectTokenizedQuery[i] == null) {
                break;
            }
            for (int j = 0; j < twoArgumentOperations.length; j++) {
                if (objectTokenizedQuery[i].equals(twoArgumentOperations[j])) {
                    hasTwoArgumentOperation = true;
                    twoArgumentType = (String) objectTokenizedQuery[i];
                    twoArgumentIndex = i;
                }
            }
        }
        // Solves queries with two argument operations.
        if (hasTwoArgumentOperation) {
            int i = 0;
            Object[][] tempResultArrayOne = new Object[100][100];
            Object[][] tempResultArrayTwo = new Object[100][100];
            Object[] leftArgument = new Object[100];
            Object[] rightArgument = new Object[100];
            // Breaks the query into a left and right argument.
            for (int j = 0; j < objectTokenizedQuery.length; j++) {
                if (objectTokenizedQuery[j] == null) {
                    break;
                }
                if (j < twoArgumentIndex) {
                    leftArgument[j] = objectTokenizedQuery[j];
                }
                if (j > twoArgumentIndex) {
                    rightArgument[i] = objectTokenizedQuery[j];
                    i++;
                }
            }
            // Checks to see how many operations are in each of the left and right arguments.
            boolean hasNoneLeft = false;
            boolean hasOneLeft = false;
            boolean hasMultipleLeft = false;
            boolean hasNoneRight = false;
            boolean hasOneRight = false;
            boolean hasMultipleRight = false;
            int count = 0;
            for (int j = 0; j < leftArgument.length; j++) {
                if (leftArgument[j] == null) {
                    break;
                }
                for (int k = 0; k < oneArgumentOperations.length; k++) {
                    if (leftArgument[j].equals(oneArgumentOperations[k])) {
                        count++;
                    }
                }
            }
            if (count == 0) {
                hasNoneLeft = true;
            } else if (count == 1) {
                hasOneLeft = true;
            } else {
                hasMultipleLeft = true;
            }
            count = 0;
            for (int j = 0; j < rightArgument.length; j++) {
                if (rightArgument[j] == null) {
                    break;
                }
                for (int k = 0; k < oneArgumentOperations.length; k++) {
                    if (rightArgument[j].equals(oneArgumentOperations[k])) {
                        count++;
                    }
                }
            }
            if (count == 0) {
                hasNoneRight = true;
            } else if (count == 1) {
                hasOneRight = true;
            } else {
                hasMultipleRight = true;
            }
            // Either creates a 2D array to be used in solution or 
            // uses recurrsion to further break down the query.
            if (hasNoneLeft) {
                tempResultArrayOne = createArray(leftArgument);
            } else {
                tempResultArrayOne = Quarterback(leftArgument);
            }
            if (hasNoneRight) {
                tempResultArrayTwo = createArray(rightArgument);
            } else {
                tempResultArrayTwo = Quarterback(rightArgument);
            }
            // Determines the operation to be used.
            if (twoArgumentType.equals("*")) {
                tempResultArray = NaturalJoin(tempResultArrayOne, tempResultArrayTwo);
            } else if (twoArgumentType.equals("X")) {
                tempResultArray = CrossProduct(tempResultArrayOne, tempResultArrayTwo);
            } else if (twoArgumentType.equals("U")) {
                tempResultArray = Union(tempResultArrayOne, tempResultArrayTwo);
            } else if (twoArgumentType.equals("INTE")) {
                tempResultArray = Intersection(tempResultArrayOne, tempResultArrayTwo);
            } else {
                // "-"
                tempResultArray = Difference(tempResultArrayOne, tempResultArrayTwo);
            }
        }
        // Solves queries without two argument operations.
        if (!hasTwoArgumentOperation) {
            boolean hasOne = false;
            boolean hasMultiple = false;
            int mostRecentIndex = 0;
            int count = 0;
            for (int j = 0; j < objectTokenizedQuery.length; j++) {
                if (objectTokenizedQuery[j] == null) {
                    break;
                }
                for (int k = 0; k < oneArgumentOperations.length; k++) {
                    if (objectTokenizedQuery[j].equals(oneArgumentOperations[k])) {
                        mostRecentIndex = j;
                        count++;
                    }
                }
            }
            if (count == 1) {
                hasOne = true;
            } else {
                hasMultiple = true;
            }
            // Determines to solve Projection or Selection.
            if (hasOne) {
                if (objectTokenizedQuery[0].equals("PROJ_")) {
                    tempResultArray = Project(objectTokenizedQuery);
                }
                if (objectTokenizedQuery[0].equals("SELE_")) {
                    tempResultArray = Select(objectTokenizedQuery);
                }
            } else {
                Object[] tempObjectTokenizedQuery = new Object[100];
                Object[] remainingObjectTokenizedQuery = new Object[100];
                int i = 0;
                int j = 0;
                for (int k = 0; k < objectTokenizedQuery.length; k++) {
                    if (objectTokenizedQuery[k] == null) {
                        break;
                    }
                    if (k < mostRecentIndex) {
                        remainingObjectTokenizedQuery[i] = objectTokenizedQuery[k];
                        i++;
                    }
                    if (k >= mostRecentIndex) {
                        tempObjectTokenizedQuery[j] = objectTokenizedQuery[k];
                        j++;
                    }
                }
                tempResultArray = Quarterback(tempObjectTokenizedQuery);
                // For when we are projecting things that needed to be solved first.
                if (remainingObjectTokenizedQuery[0].equals("PROJ_")) {
                    tempResultArray = Project(remainingObjectTokenizedQuery, tempResultArray);
                }
            }
        }
        return tempResultArray;
    }

    // Creates 2D arrays using f1-f5 fileNames.
    private static Object[][] createArray(Object[] argument) {
        Object[][] tempResultArray = new Object[100][100];
        String targetFile = "";
        for (int i = 0; i < argument.length; i++) {
            if (argument[i] == null) {
                break;
            }
            if (f1.equalsIgnoreCase((String) argument[i])) {
                targetFile = f1;
            }
            if (f2.equalsIgnoreCase((String) argument[i])) {
                targetFile = f2;
            }
            if (f3.equalsIgnoreCase((String) argument[i])) {
                targetFile = f3;
            }
            if (f4.equalsIgnoreCase((String) argument[i])) {
                targetFile = f4;
            }
            if (f5.equalsIgnoreCase((String) argument[i])) {
                targetFile = f5;
            }
        }
        if (targetFile.equalsIgnoreCase(f1)) {
            tempResultArray = FileOne;
        } else if (targetFile.equalsIgnoreCase(f2)) {
            tempResultArray = FileTwo;
        } else if (targetFile.equalsIgnoreCase(f3)) {
            tempResultArray = FileThree;
        } else if (targetFile.equalsIgnoreCase(f4)) {
            tempResultArray = FileFour;
        } else {
            tempResultArray = FileFive;
        }
        return tempResultArray;
    }

    // Single argument Project method.
    private static Object[][] Project(Object[] objectTokenizedQuery) {
        Object[][] tempResultArray = new Object[100][100];
        Object[][] tempTargetArray = new Object[100][100];
        tempTargetArray = createArray(objectTokenizedQuery);
        // Attributes are taken from the first line of the files given.
        String[] attributes = new String[100];
        int i = 1;
        int j = 0;
        while (objectTokenizedQuery[i] != null) {
            if (objectTokenizedQuery[i].equals(f1)
                    || objectTokenizedQuery[i].equals(f2)
                    || objectTokenizedQuery[i].equals(f3)
                    || objectTokenizedQuery[i].equals(f4)
                    || objectTokenizedQuery[i].equals(f5)) {
                break;
            } else {
                attributes[j] = (String) objectTokenizedQuery[i];
                j++;
            }
            i++;
        }
        // Results are added based on their location in the attributes column.
        for (int k = 0; k < tempTargetArray.length; k++) {
            for (int l = 0; l < tempTargetArray[k].length; l++) {
                if (tempTargetArray[k][l] == null) {
                    break;
                }
                for (int m = 0; m < attributes.length; m++) {
                    if (attributes[m] == null) {
                        break;
                    }
                    if (tempTargetArray[0][l].equals(attributes[m])) {
                        tempResultArray[k][l] = tempTargetArray[k][l];
                    }
                }
            }
        }
        return tempResultArray;
    }

    // Two argument Project method. 
    private static Object[][] Project(Object[] objectTokenizedQuery, Object[][] tempTargetArray) {
        Object[][] tempResultArray = new Object[100][100];
        String[] attributes = new String[100];
        // In this case, the attributes are taken from an argument.
        int i = 1;
        int j = 0;
        while (objectTokenizedQuery[i] != null) {
            attributes[j] = (String) objectTokenizedQuery[i];
            j++;
            i++;
        }
        // Results are added based on their location in the attributes column.
        for (int k = 0; k < tempTargetArray.length; k++) {
            for (int l = 0; l < tempTargetArray[k].length; l++) {
                if (tempTargetArray[k][l] == null) {
                    break;
                }
                for (int m = 0; m < attributes.length; m++) {
                    if (attributes[m] == null) {
                        break;
                    }
                    if (tempTargetArray[0][l].equals(attributes[m])) {
                        tempResultArray[k][l] = tempTargetArray[k][l];
                    }
                }
            }
        }
        return tempResultArray;
    }

    // Select method.
    private static Object[][] Select(Object[] objectTokenizedQuery) {
        Object[][] tempResultArray = new Object[100][100];
        String attribute = (String) objectTokenizedQuery[1];
        Object[][] tempTargetArray = new Object[100][100];
        String targetFile = (String) objectTokenizedQuery[4];
        // Determining which file is to be read from.
        if (targetFile.equalsIgnoreCase(f1)) {
            tempTargetArray = FileOne;
        } else if (targetFile.equalsIgnoreCase(f2)) {
            tempTargetArray = FileTwo;
        } else if (targetFile.equalsIgnoreCase(f3)) {
            tempTargetArray = FileThree;
        } else if (targetFile.equalsIgnoreCase(f4)) {
            tempTargetArray = FileFour;
        } else {
            tempTargetArray = FileFive;
        }
        int i = 0;
        int j = 0;
        int targetAttributeIndex = 0;
        int value = (int) objectTokenizedQuery[3];
        while (tempTargetArray[i][j] != null) {
            tempResultArray[i][j] = tempTargetArray[i][j];
            j++;
        }
        j = 0;
        // Reading in from the given attribute column.
        while (tempTargetArray[i][j] != null) {
            if (tempTargetArray[i][j].equals(attribute)) {
                targetAttributeIndex = j;
            }
            j++;
        }
        j = 0;
        int numberOfRows = 0;
        while (tempTargetArray[i][j] != null) {
            numberOfRows++;
            i++;
        }
        i = 1;
        j = 1;
        int k = 0;
        // Determining the comparison result to the value given in the query.
        // Less than
        if (objectTokenizedQuery[2].equals("<")) {
            for (int m = 0; m < (numberOfRows - 1); m++) {
                if ((Integer) tempTargetArray[i][targetAttributeIndex] < value) {
                    while (tempTargetArray[i][k] != null) {
                        tempResultArray[j][k] = tempTargetArray[i][k];
                        k++;
                    }
                    j++;
                    k = 0;
                }
                i++;
            }
            // Greater than
        } else if (objectTokenizedQuery[2].equals(">")) {
            for (int m = 0; m < (numberOfRows - 1); m++) {
                if ((Integer) tempTargetArray[i][targetAttributeIndex] > value) {
                    while (tempTargetArray[i][k] != null) {
                        tempResultArray[j][k] = tempTargetArray[i][k];
                        k++;
                    }
                    j++;
                    k = 0;
                }
                i++;
            }
        } else {
            // Equal to
            for (int l = 0; l < (numberOfRows - 1); l++) {
                if ((Integer) tempTargetArray[i][targetAttributeIndex] == value) {
                    while (tempTargetArray[i][k] != null) {
                        tempResultArray[j][k] = tempTargetArray[i][k];
                        k++;
                    }
                    j++;
                    k = 0;
                }
                i++;
            }
        }
        return tempResultArray;
    }

    private static Object[][] NaturalJoin(Object[][] tempTargetArrayOne, Object[][] tempTargetArrayTwo) {
        Object[][] tempResultArray = new Object[100][100];
        String[] attributesOne = new String[100];
        String[] attributesTwo = new String[100];
        String[] sharedAttributes = new String[100];
        String[] allAttributes = new String[100];
        // Determining the attributes from the first arrays given.
        for (int i = 0; i < tempTargetArrayOne.length; i++) {
            if (tempTargetArrayOne[0][i] == null) {
                break;
            }
            attributesOne[i] = (String) tempTargetArrayOne[0][i];
        }
        // Determining the attributes from the second arrays given.
        for (int i = 0; i < tempTargetArrayTwo.length; i++) {
            if (tempTargetArrayTwo[0][i] == null) {
                break;
            }
            attributesTwo[i] = (String) tempTargetArrayTwo[0][i];
        }
        // Determining if arrays one and two have any shared attributes.
        int i = 0;
        for (int j = 0; j < attributesOne.length; j++) {
            if (attributesOne[j] == null) {
                break;
            }
            for (int k = 0; k < attributesTwo.length; k++) {
                if (attributesTwo[k] == null) {
                    break;
                }
                if (attributesOne[j].equals(attributesTwo[k])) {
                    sharedAttributes[i] = attributesOne[j];
                    i++;
                }
            }
        }
        i = 0;
        for (int j = 0; j < attributesOne.length; j++) {
            if (attributesOne[j] == null) {
                break;
            }
            for (int k = 0; k < attributesTwo.length; k++) {
                if (attributesTwo[k] == null) {
                    break;
                }
                if (attributesOne[j].equals(attributesTwo[k]) == false) {
                    allAttributes[i] = attributesOne[j];
                    i++;
                    break;
                }
            }
        }
        int j = 0;
        while (attributesTwo[j] != null) {
            boolean isContained = false;
            for (int k = 0; k < allAttributes.length; k++) {
                if (allAttributes[k] == null) {
                    break;
                }
                if (allAttributes[k].equals(attributesTwo[j])) {
                    isContained = true;
                }
            }
            if (!isContained) {
                allAttributes[i] = attributesTwo[j];
                i++;
            }
            j++;
        }
        // Writing attributes to result.
        int k = 0;
        for (int l = 0; l < allAttributes.length; l++) {
            if (allAttributes[l] == null) {
                break;
            }
            tempResultArray[0][l] = allAttributes[l];
        }
        int targetAttributeIndexOne = 0;
        int targetAttributeIndexTwo = 0;
        i = 0;
        j = 0;
        while (tempTargetArrayOne[i][j] != null) {
            if (tempTargetArrayOne[i][j].equals(sharedAttributes[0])) {
                targetAttributeIndexOne = j;
            }
            j++;
        }
        j = 0;
        // Determining number of rows of Array one.
        int numberOfRowsOne = 0;
        while (tempTargetArrayOne[i][j] != null) {
            numberOfRowsOne++;
            i++;
        }
        i = 0;
        while (tempTargetArrayTwo[i][j] != null) {
            if (tempTargetArrayTwo[i][j].equals(sharedAttributes[0])) {
                targetAttributeIndexTwo = j;
            }
            j++;
        }
        j = 0;
        // Determining number of rows of Array two.
        int numberOfRowsTwo = 0;
        while (tempTargetArrayTwo[i][j] != null) {
            numberOfRowsTwo++;
            i++;
        }
        i = 0;
        j = 1;
        k = 0;
        // Searching through attributes to add to results.
        for (int l = 1; l < (numberOfRowsOne); l++) {
            for (int m = 1; m < (numberOfRowsTwo); m++) {
                if (tempTargetArrayOne[l][targetAttributeIndexOne].equals(tempTargetArrayTwo[m][targetAttributeIndexTwo])) {
                    i = 0;
                    for (int n = 0; n < allAttributes.length; n++) {
                        if (allAttributes[n] == null) {
                            break;
                        }
                        if (allAttributes[n].equals(tempTargetArrayOne[0][i])) {
                            tempResultArray[j][n] = tempTargetArrayOne[l][i];
                            i++;
                            k++;
                        }
                    }
                    i = 0;
                    for (int n = 0; n < allAttributes.length; n++) {
                        if (allAttributes[n] == null) {
                            break;
                        }
                        if (allAttributes[n].equals(tempTargetArrayTwo[0][i])) {
                            tempResultArray[j][n] = tempTargetArrayTwo[m][i];
                            i++;
                            k++;
                        }
                    }
                    j++;
                    k = 0;
                }
            }
        }
        return tempResultArray;
    }

    // This was something I could not figure out.
    private static Object[][] CrossProduct(Object[][] tempResultArrayOne, Object[][] tempResultArrayTwo) {
        System.out.println("CrossProduct was not implemented...");
        return null;
    }

    private static Object[][] Union(Object[][] tempResultArrayOne, Object[][] tempResultArrayTwo) {
        Object[][] tempResultArray = new Object[100][100];
        int tempResultArrayI = 0;
        Object[] tempHolderOne = new Object[100];
        Object[] tempHolderTwo = new Object[100];
        Object[] duplicateCheck = new Object[100];
        boolean isDuplicate = false;
        // Determining the attributes of Array one.
        for (int i = 0; i < tempResultArrayOne[0].length; i++) {
            if (tempResultArrayOne[0][i] == null) {
                break;
            }
            tempHolderOne[i] = tempResultArrayOne[0][i];
        }
        // Determining the attributes of Array two.
        for (int i = 0; i < tempResultArrayTwo[0].length; i++) {
            if (tempResultArrayTwo[0][i] == null) {
                break;
            }
            tempHolderTwo[i] = tempResultArrayTwo[0][i];
        }
        // Checking if attributes isEqual.
        boolean isEqual = true;
        for (int j = 0; j < tempHolderOne.length; j++) {
            if (!tempHolderOne[j].equals(tempHolderTwo[j])) {
                isEqual = false;
                break;
            }
            if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] == null) {
                break;
            }
            if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] != null) {
                isEqual = false;
                break;
            }
            if (tempHolderOne[j + 1] != null && tempHolderTwo[j + 1] == null) {
                isEqual = false;
                break;
            }
        }
        if (isEqual) {
            for (int i = 0; i < tempHolderOne.length; i++) {
                tempResultArray[0][i] = tempHolderOne[i];
            }
            tempResultArrayI++;
        }
        // Checking the contents of Array one against the contents of Array two.
        for (int i = 1; i < tempResultArrayOne.length; i++) {
            if (tempResultArrayOne[i][0] == null) {
                break;
            }
            for (int j = 0; j < tempResultArrayOne[i].length; j++) {
                if (tempResultArrayOne[i][j] == null) {
                    break;
                }
                tempHolderOne[j] = tempResultArrayOne[i][j];
            }
            isEqual = false;
            for (int k = 1; k < tempResultArrayTwo.length; k++) {
                if (tempResultArrayTwo[k][0] == null) {
                    break;
                }
                if (isEqual) {
                    break;
                }
                for (int m = 0; m < tempResultArrayTwo[k].length; m++) {
                    if (tempResultArrayTwo[k][m] == null) {
                        break;
                    }
                    tempHolderTwo[m] = tempResultArrayTwo[k][m];
                }
                for (int j = 0; j < tempHolderOne.length; j++) {
                    // Determining isEqual
                    if (tempHolderOne[j].equals(tempHolderTwo[j])) {
                        isEqual = true;
                        break;
                    }
                    if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] != null) {
                        isEqual = false;
                        break;
                    }
                    if (tempHolderOne[j + 1] != null && tempHolderTwo[j + 1] == null) {
                        isEqual = false;
                        break;
                    }
                }
                // Checking to see if tempHolderOne has been used previously.
                isDuplicate = true;
                for (int n = 0; n < tempHolderOne.length; n++) {
                    if (!tempHolderOne[n].equals(duplicateCheck[n])) {
                        isDuplicate = false;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] != null) {
                        isDuplicate = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && duplicateCheck[n + 1] == null) {
                        isDuplicate = false;
                        break;
                    }
                }
            }
            // Adding to result if criteria is met.
            if (!isEqual && !isDuplicate) {
                for (int j = 0; j < tempHolderOne.length; j++) {
                    if (tempHolderOne[j] == null) {
                        break;
                    }
                    tempResultArray[tempResultArrayI][j] = tempHolderOne[j];
                    duplicateCheck[j] = tempHolderOne[j];
                }
                tempResultArrayI++;
            }
        }
        // Checking the contents of Array two against the contents of Array one.
        for (int i = 1; i < tempResultArrayTwo.length; i++) {
            if (tempResultArrayTwo[i][0] == null) {
                break;
            }
            for (int j = 0; j < tempResultArrayTwo[i].length; j++) {
                if (tempResultArrayTwo[i][j] == null) {
                    break;
                }
                tempHolderOne[j] = tempResultArrayTwo[i][j];
            }
            isDuplicate = true;
            for (int n = 0; n < tempHolderOne.length; n++) {
                // Checking to see if tempHolderOne has been used previously.
                if (!tempHolderOne[n].equals(duplicateCheck[n])) {
                    isDuplicate = false;
                }
                if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] == null) {
                    break;
                }
                if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] != null) {
                    isDuplicate = false;
                    break;
                }
                if (tempHolderOne[n + 1] != null && duplicateCheck[n + 1] == null) {
                    isDuplicate = false;
                    break;
                }
            }
            // Adding to result if criteria is met.
            if (!isDuplicate) {
                for (int j = 0; j < tempHolderOne.length; j++) {
                    if (tempHolderOne[j] == null) {
                        break;
                    }
                    tempResultArray[tempResultArrayI][j] = tempHolderOne[j];
                    duplicateCheck[j] = tempHolderOne[j];
                }
                tempResultArrayI++;
            }
        }
        return tempResultArray;
    }

    private static Object[][] Intersection(Object[][] tempResultArrayOne, Object[][] tempResultArrayTwo) {
        Object[][] tempResultArray = new Object[100][100];
        int tempResultArrayI = 0;
        Object[] tempHolderOne = new Object[100];
        Object[] tempHolderTwo = new Object[100];
        Object[] duplicateCheck = new Object[100];
        // Determining the attributes of Array one.
        for (int i = 0; i < tempResultArrayOne[0].length; i++) {
            if (tempResultArrayOne[0][i] == null) {
                break;
            }
            tempHolderOne[i] = tempResultArrayOne[0][i];
        }
        // Determining the attributes of Array two
        for (int i = 0; i < tempResultArrayTwo[0].length; i++) {
            if (tempResultArrayTwo[0][i] == null) {
                break;
            }
            tempHolderTwo[i] = tempResultArrayTwo[0][i];
        }
        // Checking if attributes isEqual.
        boolean isEqual = true;
        for (int j = 0; j < tempHolderOne.length; j++) {
            if (!tempHolderOne[j].equals(tempHolderTwo[j])) {
                isEqual = false;
                break;
            }
            if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] == null) {
                break;
            }
            if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] != null) {
                isEqual = false;
                break;
            }
            if (tempHolderOne[j + 1] != null && tempHolderTwo[j + 1] == null) {
                isEqual = false;
                break;
            }
        }
        if (isEqual) {
            for (int i = 0; i < tempHolderOne.length; i++) {
                tempResultArray[0][i] = tempHolderOne[i];
            }
            tempResultArrayI++;
        }
        // Checking the contents of Array one against the contents of Array two.
        for (int i = 1; i < tempResultArrayOne.length; i++) {
            if (tempResultArrayOne[i][0] == null) {
                break;
            }
            for (int j = 0; j < tempResultArrayOne[i].length; j++) {
                if (tempResultArrayOne[i][j] == null) {
                    break;
                }
                tempHolderOne[j] = tempResultArrayOne[i][j];
            }
            for (int k = 1; k < tempResultArrayTwo.length; k++) {
                if (tempResultArrayTwo[k][0] == null) {
                    break;
                }
                isEqual = false;
                for (int m = 0; m < tempResultArrayTwo[k].length; m++) {
                    if (tempResultArrayTwo[k][m] == null) {
                        break;
                    }
                    if (isEqual) {
                        break;
                    }
                    tempHolderTwo[m] = tempResultArrayTwo[k][m];
                }
                // Determining isEqual
                for (int n = 0; n < tempHolderOne.length; n++) {
                    isEqual = false;
                    if (tempHolderOne[n].equals(tempHolderTwo[n])) {
                        isEqual = true;
                        break;
                    } else {
                        isEqual = false;
                    }
                    if (tempHolderOne[n + 1] == null && tempHolderTwo[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && tempHolderTwo[n + 1] != null) {
                        isEqual = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && tempHolderTwo[n + 1] == null) {
                        isEqual = false;
                        break;
                    }
                }
                // Checking to see if tempHolderOne has been used previously.
                boolean isDuplicate = true;
                for (int n = 0; n < tempHolderOne.length; n++) {
                    if (!tempHolderOne[n].equals(duplicateCheck[n])) {
                        isDuplicate = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] != null) {
                        isDuplicate = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && duplicateCheck[n + 1] == null) {
                        isDuplicate = false;
                        break;
                    }
                }
                // Adding to result if criteria is met.
                if (isEqual && !isDuplicate) {
                    for (int j = 0; j < tempHolderOne.length; j++) {
                        if (tempHolderOne[j] == null) {
                            break;
                        }
                        tempResultArray[tempResultArrayI][j] = tempHolderOne[j];
                        duplicateCheck[j] = tempHolderOne[j];
                    }
                    tempResultArrayI++;
                }

            }
        }
        // Because intersection, it is not necessary to check two against one.
        return tempResultArray;
    }

    // Determining the difference between the two arguments given.
    private static Object[][] Difference(Object[][] tempResultArrayOne, Object[][] tempResultArrayTwo) {
        Object[][] tempResultArray = new Object[100][100];
        int tempResultArrayI = 0;
        Object[] tempHolderOne = new Object[100];
        Object[] tempHolderTwo = new Object[100];
        Object[] duplicateCheck = new Object[100];
        // Determining if the two arrays given share similar attributes.
        for (int i = 0; i < tempResultArrayOne[0].length; i++) {
            if (tempResultArrayOne[0][i] == null) {
                break;
            }
            tempHolderOne[i] = tempResultArrayOne[0][i];
        }
        for (int i = 0; i < tempResultArrayTwo[0].length; i++) {
            if (tempResultArrayTwo[0][i] == null) {
                break;
            }
            tempHolderTwo[i] = tempResultArrayTwo[0][i];
        }
        boolean isEqual = true;
        for (int j = 0; j < tempHolderOne.length; j++) {
            if (!tempHolderOne[j].equals(tempHolderTwo[j])) {
                isEqual = false;
                break;
            }
            if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] == null) {
                break;
            }
            if (tempHolderOne[j + 1] == null && tempHolderTwo[j + 1] != null) {
                isEqual = false;
                break;
            }
            if (tempHolderOne[j + 1] != null && tempHolderTwo[j + 1] == null) {
                isEqual = false;
                break;
            }
        }
        if (isEqual) {
            for (int i = 0; i < tempHolderOne.length; i++) {
                tempResultArray[0][i] = tempHolderOne[i];
            }
            tempResultArrayI++;
        }
        // Checking the contents of Array one against the contents of Array two.
        for (int i = 1; i < tempResultArrayOne.length; i++) {
            if (tempResultArrayOne[i][0] == null) {
                break;
            }
            for (int j = 0; j < tempResultArrayOne[i].length; j++) {
                if (tempResultArrayOne[i][j] == null) {
                    break;
                }
                tempHolderOne[j] = tempResultArrayOne[i][j];
            }
            isEqual = false;
            boolean isLast = false;
            for (int k = 1; k < tempResultArrayTwo.length; k++) {
                if (tempResultArrayTwo[k][0] == null) {
                    break;
                }
                if (isEqual) {
                    break;
                }
                for (int m = 0; m < tempResultArrayTwo[k].length; m++) {
                    if (tempResultArrayTwo[k][m] == null) {
                        break;
                    }
                    tempHolderTwo[m] = tempResultArrayTwo[k][m];
                }
                if (tempResultArrayTwo[k + 1][0] == null) {
                    isLast = true;
                }
                // Determining isEqual
                for (int n = 0; n < tempHolderOne.length; n++) {
                    if (tempHolderOne[n].equals(tempHolderTwo[n])) {
                        isEqual = true;
                        break;
                    } else {
                        isEqual = false;
                    }
                    if (tempHolderOne[n + 1] == null && tempHolderTwo[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && tempHolderTwo[n + 1] != null) {
                        isEqual = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && tempHolderTwo[n + 1] == null) {
                        isEqual = false;
                        break;
                    }
                }
                // Checking to see if tempHolderOne has been used previously.
                boolean isDuplicate = true;
                for (int n = 0; n < tempHolderOne.length; n++) {
                    if (!tempHolderOne[n].equals(duplicateCheck[n])) {
                        isDuplicate = false;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] != null) {
                        isDuplicate = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && duplicateCheck[n + 1] == null) {
                        isDuplicate = false;
                        break;
                    }
                }
                // Adding to result if criteria is met.
                if (!isEqual && !isDuplicate && isLast) {
                    for (int j = 0; j < tempHolderOne.length; j++) {
                        if (tempHolderOne[j] == null) {
                            break;
                        }
                        tempResultArray[tempResultArrayI][j] = tempHolderOne[j];
                        duplicateCheck[j] = tempHolderOne[j];
                    }
                    tempResultArrayI++;
                }
            }
        }
        // Checking the contents of Array two against Array one.
        for (int i = 1; i < tempResultArrayTwo.length; i++) {
            if (tempResultArrayTwo[i][0] == null) {
                break;
            }
            for (int j = 0; j < tempResultArrayTwo[i].length; j++) {
                if (tempResultArrayTwo[i][j] == null) {
                    break;
                }
                tempHolderOne[j] = tempResultArrayTwo[i][j];
            }
            isEqual = false;
            boolean isLast = false;
            for (int k = 1; k < tempResultArrayOne.length; k++) {
                if (tempResultArrayOne[k][0] == null) {
                    break;
                }
                if (isEqual) {
                    break;
                }
                for (int m = 0; m < tempResultArrayOne[k].length; m++) {
                    if (tempResultArrayOne[k][m] == null) {
                        break;
                    }
                    tempHolderTwo[m] = tempResultArrayOne[k][m];
                }
                if (tempResultArrayOne[k + 1][0] == null) {
                    isLast = true;
                }
                // Determining isEqual
                for (int n = 0; n < tempHolderOne.length; n++) {
                    if (tempHolderOne[n].equals(tempHolderTwo[n])) {
                        isEqual = true;
                        break;
                    } else {
                        isEqual = false;
                    }
                    if (tempHolderOne[n + 1] == null && tempHolderTwo[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && tempHolderTwo[n + 1] != null) {
                        isEqual = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && tempHolderTwo[n + 1] == null) {
                        isEqual = false;
                        break;
                    }
                }
                // Checking to see if tempHolderOne has been used previously.
                boolean isDuplicate = true;
                for (int n = 0; n < tempHolderOne.length; n++) {
                    if (!tempHolderOne[n].equals(duplicateCheck[n])) {
                        isDuplicate = false;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] == null) {
                        break;
                    }
                    if (tempHolderOne[n + 1] == null && duplicateCheck[n + 1] != null) {
                        isDuplicate = false;
                        break;
                    }
                    if (tempHolderOne[n + 1] != null && duplicateCheck[n + 1] == null) {
                        isDuplicate = false;
                        break;
                    }
                }
                // Adding to result if criteria is met.
                if (!isEqual && !isDuplicate && isLast) {
                    for (int j = 0; j < tempHolderOne.length; j++) {
                        if (tempHolderOne[j] == null) {
                            break;
                        }
                        tempResultArray[tempResultArrayI][j] = tempHolderOne[j];
                        duplicateCheck[j] = tempHolderOne[j];
                    }
                    tempResultArrayI++;
                }
            }
        }
        return tempResultArray;
    }

    // Printing the final results to RAoutput.csv
    private static void printResults() {
        File csvOutputFile = new File("RAoutput.csv");
        try (PrintWriter pw = new PrintWriter(csvOutputFile)) {
            for (int i = 0; i < Result.length; i++) {
                if (Result[i][0] == null) {
                    break;
                }
                for (int j = 0; j < Result[i].length; j++) {
                    if (Result[i][j] == null) {
                        break;
                    }
                    pw.print(Result[i][j] + " ");
                }
                pw.print("\n");
            }
            pw.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
