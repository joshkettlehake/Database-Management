/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs4700.project1.kettlehake;

/**
 *
 * @author Joshua
 */


public class Movies {
    private String MNAME;
    private String MNO;
    
    Movies() {
    }
    
    public Movies(String name, String number) {
    this.MNAME = name;
    this.MNO = number;
    }

    

    public String getMNAME() {
        return MNAME;
    }

    public void setMNAME(String name) {
        this.MNAME = name;
    }

    public String getMNO() {
        return MNO;
    }

    public void setMNO(String number) {
        this.MNO = number;
    }
    
}
