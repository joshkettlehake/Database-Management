/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs4700.project1.kettlehake;

/**
 *
 * @author Joshua
 */
class Actors {
    private String ANAME;
    private String ANO;

    Actors() {
    }
    
    public Actors(String name, String number) {
        this.ANAME = name;
        this.ANO = number;
    }

    public String getANAME() {
        return ANAME;
    }

    public void setANAME(String name) {
        this.ANAME = name;
    }

    public String getANO() {
        return ANO;
    }

    public void setANO(String number) {
        this.ANO = number;
    }
}
